# hanhart.pkg

## An R package for consolidating data and making it easier to interpret.

This R package takes overwhelming data and condenses it, then turns the final plot pink. 