function 2- a function to manipulate, subset, or transform data 
for this function i will use mutate in order to convert the weight in what we presume is grams to weight in pounds. this will allow me to get a better understanding and picture of the mass of the animal.
example function: mutate(surveysnonas, weight_in_lbs = weight*0.0022)